package klausur;

import java.util.Scanner;

/**
 * Uebungsfragen
 */
public class Uebungsfragen {

  public static final double PI = 3.1415;

  public static void main(String[] args) {
    umrechnung();
    befehlsfolge();
    verkuerzen();

    Scanner scanner = new Scanner(System.in);
    System.out.println(
      "Geben Sie den höchsten zu berechnenden Wert für die Fakultät ein:"
    );
    int maxFakultaet = scanner.nextInt();
    // int maxFakultaet = 10;
    doWork(maxFakultaet);
    scanner.close();

    klausurnoten();
    array();
    rechentabelle();
  }

  private static void initialisierung() {
    // short  wert  = 763443;
    // long   wert2 = 1234_5678_5678_1234;
    int wert3 = 22___232233;
    double wert4 = 7D;
    // double wert5 = 2.00_D;
    float wert6 = 2.000000000001F;
    float wert7 = 02.0f;
  }

  private static void typenumwandlung() {
    float a = 39.5F;
    long d = 5000000000L;
    int e = 500000;
    int g = 83; // ab hier lösen
    // int    v1_1 = d - e * g;
    long v1_2 = d - e * g;
    double v1_3 = d - e * g;
    double v2_1 = a / d;
    float v2_2 = a / d;
    // long   v2_3 = a / d;
  }

  private static void umrechnung() {
    int wert1 = 0b00101001;
    String wert2 = Integer.toBinaryString(945);
    int wert3 = 0b011100010110;

    System.out.println(wert1 + " " + wert2 + " " + wert3);
  }

  private static void legalIllegal() {
    String Örkel;
    String Oerkel;
    String Micro$oft;
    // String 1alala;
    String Lalala;
  }

  private static void typenbestimmung() {
    long a = 3;
    int b = 9;
    short c = 1;
    byte d = 2;

    long wert1 = d / b * a;
    int wert2 = c + b * (d + 1);
    int wert3 = d / (c - 1) * b / 2;
    int wert4 = d % b;
    int wert5 = -c % b;
  }

  private static void befehlsfolge() {
    int zaehler = 0;
    int n = 13;
    while (n != 1) {
      if (n % 2 == 0) {
        n = n / 2;
      } else {
        n = 3 * n + 1;
      }
      zaehler = zaehler + 1;
    }
    System.out.println("Ergebnis: " + zaehler);
  }

  private static void verkuerzen() {
    int a;
    int b = 2;
    int c = 3;
    int d = 4;

    if (b <= c) {
      a = b + b;
    } else {
      if (c <= d) {
        a = c + c;
      } else {
        a = d * 2;
      }
    }
    System.out.println(a);
    a = (b <= c) ? b + b : (c <= d) ? c + c : d * 2;
    System.out.println(a);
  }

  private static void doWork(int maxFakultaet) {
    long fak = 1;

    for (int i = 1; i <= maxFakultaet; i++) {
      fak *= i;

      if (fak <= maxFakultaet && fak > 0) {
        System.out.println("x = " + i + ", fak(" + i + ") = " + fak);
      }
    }
  }

   private static void klausurnoten() {
    int punkte = 10;

    if (punkte <= 41 && punkte >= 50) {
      System.out.println("Super");
    } else if (punkte >= 31 && punkte <= 40) {
      System.out.println("Gut");
          } else if (punkte >= 21 && punkte <= 30) {
      System.out.println("Mittelgut");
    } else if (punkte >= 11 && punkte <= 20) {
      System.out.println("Naja");
    } else if (punkte >= 0 && punkte <= 10) {
      System.out.println("Durchgefallen");
    }

    String klausurnote = switch (punkte) {
      case 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10       -> "Durchgefallen";
      case 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 -> "Naja";
      case 21, 22, 23, 24, 25, 26, 27, 28, 29, 30 -> "Mittelgut";
      case 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 -> "Gut";
      case 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 -> "Super";
      default -> "N/A";
    };
    System.out.println(klausurnote);

    String klausurnote2 = switch (punkte) {
      case 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10      : yield "Durchgefallen";
      case 11, 12, 13, 14, 15, 16, 17, 18, 19, 20: yield "Naja";
      case 21, 22, 23, 24, 25, 26, 27, 28, 29, 30: yield "Mittelgut";
      case 31, 32, 33, 34, 35, 36, 37, 38, 39, 40: yield "Gut";
      case 41, 42, 43, 44, 45, 46, 47, 48, 49, 50: yield "Super";
      default: yield "N/A";
    };
    System.out.println(klausurnote2);

    switch (punkte) {
      case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:
      System.out.println("Durchgefallen");
        break;
      case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20:
      System.out.println("Naja");
        break;
      case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30:
      System.out.println("Mittelgut");
        break;
      case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40:
      System.out.println("Gut");
        break;
      case 41: case 42: case 43: case 44: case 45: case 46: case 47: case 48: case 49: case 50:
      System.out.println("Super");
        break;
      default:
      System.out.println("N/A");
        break;
    }

    int note = 0;
    if (note < 0) note = 0; else {
      note--;
      note /= 10;
    }
    // if Abfrage theoretisch nicht nötig da bei einer -1 auf 0 gekürzt wird, bei int
    String klausurnote3 = switch (note) {
      case 0    -> "Durchgefallen";
      case 1    -> "Naja";
      case 2    -> "Mittelgut";
      case 3    -> "Gut";
      case 4, 5 -> "Super";
      default   -> "N/A";
    };
    System.out.println(klausurnote3);
  }

  private static void array() {
    double[] array = new double[20];
    for (int i = 0; i < array.length; i++) {
      array[i] = i * 2;
    }
    for (int i = array.length - 1; i >= 0; i--) {
      System.out.print(array[i] + " ");
    }
    System.out.println();
  }

  private static void rechentabelle() {
    int[][] ereignistabelle = new int[10][10];
    for (int i = 0; i < ereignistabelle.length; i++) {
      for (int j = 0; j < ereignistabelle[i].length; j++) {
        ereignistabelle[i][j] = (j + 1) * (i + 1);
      }
    }
    for (int[] zahl : ereignistabelle) {
      for (int zahl2 : zahl) {
        System.out.printf("%4d", zahl2);
      }
      System.out.println();
    }
  }

  private double Mehode5() {
    return PI;
  }
}
