package klausur.kreis;

/**
 * Kreis
 */
public class Kreis {

  public double radius;
  private double x;
  private double y;
  public Fuellart fuellart;

  public Kreis() {
    this.radius = 0;
    this.x = 0;
    this.y = 0;
  }

  public double getRadius() {
    return this.radius;
  }

  public void setRadius(double radius) {
    this.radius = radius;
  }

  public double getX() {
    return this.x;
  }

  public void setX(double x) {
    this.x = x;
  }

  public double getY() {
    return this.y;
  }

  public void setY(double y) {
    this.y = y;
  }

  public Fuellart getFuellart() {
    return this.fuellart;
  }

  public void setFuellart(Fuellart fuellart) {
    this.fuellart = fuellart;
  }

  public void verschiebe(double deltaX, double deltaY) {
    this.x += deltaX;
    this.y += deltaY;
  }

  public double flaeche() {
    return Math.PI * Math.pow(this.radius, 2);
  }

  public enum Fuellart {
    EMPTY,
    FILLED,
    DOTTED,
  }
}
