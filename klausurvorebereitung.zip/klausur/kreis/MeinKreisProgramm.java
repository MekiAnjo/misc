package klausur.kreis;

import klausur.kreis.Kreis.Fuellart;

/**
 * MeinKreisProgramm
 */
public class MeinKreisProgramm {

  public static void main(String[] args) {
    Kreis meinKreis = new Kreis();
    meinKreis.setRadius(10.5);
    meinKreis.setX(100);
    meinKreis.setY(200);
    meinKreis.setFuellart(Fuellart.DOTTED);

    meinKreis.verschiebe(50, -25);

    System.out.println(meinKreis.flaeche());

    Kreisabschnitt meinHalbkreis = new Kreisabschnitt();
    meinHalbkreis.setOeffnungswinkel(110);
    meinHalbkreis.setRadius(15);
    meinHalbkreis.setX(200);
    meinHalbkreis.setY(100);
    meinHalbkreis.setFuellart(Fuellart.DOTTED);
  }
}
