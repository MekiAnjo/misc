package klausur.kreis;

/**
 * Kreisabschnitt
 */
public final class Kreisabschnitt extends Kreis {

  public double oeffnungswinkel;

  public Kreisabschnitt() {
    super();
    this.oeffnungswinkel = 0;
  }

  public double getOeffnungswinkel() {
    return this.oeffnungswinkel;
  }

  public void setOeffnungswinkel(double oeffnungswinkel) {
    this.oeffnungswinkel = oeffnungswinkel;
  }

  @Override
  public double flaeche() {
    return Math.PI * Math.pow(radius, 2) * this.oeffnungswinkel / 360;
  }
}
