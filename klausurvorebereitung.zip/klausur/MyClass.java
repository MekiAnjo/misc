package klausur;

public class MyClass {
  public static void main(String args[]) {
    int a = 5;
    for (int i = 0; i < 10; i++) {
      System.out.println(i);
      System.out.println(a);
    }
    System.out.println(a);
 /*   System.out.println(i);*/
  }
}
